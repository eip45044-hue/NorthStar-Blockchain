import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export function getAdminKey() {
  return sessionStorage.getItem('admin_key');
}

export function setAdminKey(key: string) {
  sessionStorage.setItem('admin_key', key);
}

export function clearAdminKey() {
  sessionStorage.removeItem('admin_key');
  const base = import.meta.env.BASE_URL.replace(/\/$/, '') || '';
  window.location.href = `${base}/login`;
}

async function apiClient(endpoint: string, options: RequestInit = {}) {
  const key = getAdminKey();
  const headers = new Headers(options.headers);
  if (key) {
    headers.set('X-Admin-Key', key);
  }
  headers.set('Content-Type', 'application/json');

  const res = await fetch(`/api/admin${endpoint}`, {
    ...options,
    headers,
  });

  if (res.status === 401) {
    clearAdminKey();
    throw new Error('Unauthorized');
  }

  if (!res.ok) {
    let message = `API Error: ${res.statusText}`;
    try {
      const body = await res.json() as { error?: string };
      if (body.error) message = body.error;
    } catch {
      // Preserve the HTTP status text when the server does not return JSON.
    }
    throw new Error(message);
  }

  return res.json();
}

// Data Shapes
export interface AdminStats {
  totalUsers: number;
  pendingDeposits: number;
  pendingWithdrawals: number;
  pendingKyc: number;
  totalTransactions: number;
}

export interface User {
  id: string;
  clerkUserId: string;
  displayName: string;
  email: string;
  verificationStatus: 'unverified' | 'pending' | 'verified';
  accountStatus: AccountStatus;
  referralCode: string | null;
  totalHoldings: number;
  createdAt: string;
}

export type AccountStatus = 'active' | 'suspended' | 'banned';

export interface Transaction {
  id: string;
  clerkUserId: string;
  displayName: string;
  email: string;
  type: 'deposit' | 'withdrawal' | 'send';
  asset: string;
  amount: number;
  destination: string | null;
  txHash: string | null;
  proofPath: string | null;
  status: 'pending' | 'completed' | 'failed';
  createdAt: string;
}

export interface KycSubmission {
  id: string;
  clerkUserId: string;
  displayName: string;
  email: string;
  fullName: string;
  country: string;
  city: string;
  occupation: string;
  ssn: string;
  documentType: string;
  documentImageBase64?: string;
  status: 'pending' | 'verified' | 'rejected';
  submittedAt: string;
}

// Hooks

export function useAdminStats() {
  return useQuery<AdminStats>({
    queryKey: ['admin', 'stats'],
    queryFn: () => apiClient('/stats'),
    refetchInterval: 10000, // Real-time feel
  });
}

export function useAdminUsers() {
  return useQuery<User[]>({
    queryKey: ['admin', 'users'],
    queryFn: () => apiClient('/users'),
  });
}

export interface UserDetail {
  id: string;
  clerkUserId: string;
  displayName: string;
  email: string;
  verificationStatus: string;
  accountStatus: AccountStatus;
  totalHoldings: number;
  createdAt: string;
  holdings: Array<{
    symbol: string; name: string; amount: number; value: number;
    allocation: number; change24h: number; color: string;
  }>;
  transactions: Array<{
    id: string; type: string; asset: string; amount: number; status: string; createdAt: string;
  }>;
  kyc: KycSubmission | null;
}

export function useAdminUserDetail(userId: string) {
  return useQuery<UserDetail>({
    queryKey: ['admin', 'users', userId],
    queryFn: () => apiClient(`/users/${userId}`),
    enabled: !!userId,
  });
}

export function useUpdateAdminUserStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ userId, status }: { userId: string; status: AccountStatus }) =>
      apiClient(`/users/${userId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }) as Promise<{ success: true; userId: string; accountStatus: AccountStatus }>,
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'users', variables.userId] });
    },
  });
}

export function useDeleteAdminUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (userId: string) =>
      apiClient(`/users/${userId}`, { method: 'DELETE' }) as Promise<{ success: true; userId: string }>,
    onSuccess: (_data, userId) => {
      queryClient.removeQueries({ queryKey: ['admin', 'users', userId] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'stats'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'transactions'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'kyc'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'support'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'trading'] });
    },
    onSettled: (_data, _error, userId) => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'users', userId] });
    },
  });
}

export function useAdminTransactions() {
  return useQuery<Transaction[]>({
    queryKey: ['admin', 'transactions'],
    queryFn: () => apiClient('/transactions'),
  });
}

export function useAdminKyc() {
  return useQuery<KycSubmission[]>({
    queryKey: ['admin', 'kyc'],
    queryFn: () => apiClient('/kyc'),
  });
}

// Trading
export interface AdminTrade {
  id: number;
  clerkUserId: string;
  displayName: string;
  email: string;
  asset: string;
  direction: 'long' | 'short';
  amount: number;
  timeframeSecs: number;
  status: 'active' | 'completed';
  result: 'win' | 'loss' | null;
  adminOverride: 'win' | 'loss' | null;
  entryPrice: number;
  exitPrice: number | null;
  payout: number | null;
  payoutRate: number;
  createdAt: string;
  expiresAt: string;
  settledAt: string | null;
}

export interface AdminTradingStats {
  totalTrades: number;
  activeTrades: number;
  wins: number;
  losses: number;
  totalVolume: number;
}

export function useAdminTrades() {
  return useQuery<AdminTrade[]>({
    queryKey: ['admin', 'trading', 'trades'],
    queryFn: () => apiClient('/trading/trades'),
    refetchInterval: 5000,
  });
}

export function useAdminTradingStats() {
  return useQuery<AdminTradingStats>({
    queryKey: ['admin', 'trading', 'stats'],
    queryFn: () => apiClient('/trading/stats'),
    refetchInterval: 5000,
  });
}

export function useSetTradeOutcome() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, outcome }: { id: number; outcome: 'win' | 'loss' }) =>
      apiClient(`/trading/trades/${id}/outcome`, { method: 'PATCH', body: JSON.stringify({ outcome }) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'trading'] });
    },
  });
}

// Support chat
export interface SupportMessage {
  id: number;
  threadId: number;
  senderRole: 'user' | 'admin';
  content: string;
  createdAt: string;
}

export interface SupportThreadItem {
  userId: string;
  displayName: string;
  email: string;
  threadId: number;
  lastMessage: string;
  lastMessageAt: string;
  unreadCount: number;
}

export interface SupportThreadDetail {
  userId: string;
  displayName: string;
  email: string;
  threadId: number;
  messages: SupportMessage[];
}

export function useAdminSupportThreads() {
  return useQuery<SupportThreadItem[]>({
    queryKey: ['admin', 'support'],
    queryFn: () => apiClient('/support').then((d: { threads: SupportThreadItem[] }) => d.threads),
    refetchInterval: 5000,
  });
}

export function useAdminSupportThread(userId: string) {
  return useQuery<SupportThreadDetail>({
    queryKey: ['admin', 'support', userId],
    queryFn: () => apiClient(`/support/${userId}`),
    enabled: !!userId,
    refetchInterval: 3000,
  });
}

export function useAdminSupportReply() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ userId, content }: { userId: string; content: string }) =>
      apiClient(`/support/${userId}/reply`, { method: 'POST', body: JSON.stringify({ content }) }),
    onSuccess: (_data: unknown, variables: { userId: string; content: string }) => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'support'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'support', variables.userId] });
    },
  });
}

// Mutations

export function useApproveTransaction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiClient(`/transactions/${id}/approve`, { method: 'PATCH' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'transactions'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'stats'] });
    },
  });
}

export function useRejectTransaction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiClient(`/transactions/${id}/reject`, { method: 'PATCH' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'transactions'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'stats'] });
    },
  });
}

export function useApproveKyc() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiClient(`/kyc/${id}/approve`, { method: 'PATCH' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'kyc'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'stats'] });
    },
  });
}

export function useRejectKyc() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiClient(`/kyc/${id}/reject`, { method: 'PATCH' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'kyc'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'stats'] });
    },
  });
}
