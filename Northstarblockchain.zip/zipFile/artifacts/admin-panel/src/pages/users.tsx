import { useState } from 'react';
import {
  useAdminUsers,
  useAdminUserDetail,
  useUpdateAdminUserStatus,
  useDeleteAdminUser,
  type AccountStatus,
  type User as AdminUser,
} from '@/lib/api';
import {
  Search, ShieldAlert, ShieldCheck, Shield, Loader2,
  ArrowUpRight, ArrowDownLeft, Coins, FileCheck,
  Ban, PauseCircle, RotateCcw, Trash2, AlertTriangle,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

function money(v = 0) {
  return '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function typeIcon(type: string) {
  if (type === 'deposit') return <ArrowDownLeft className="w-4 h-4 text-emerald-400" />;
  if (type === 'withdrawal' || type === 'send') return <ArrowUpRight className="w-4 h-4 text-rose-400" />;
  return <Coins className="w-4 h-4 text-muted-foreground" />;
}

function StatusBadge({ status }: { status: string }) {
  const cls: Record<string, string> = {
    completed: 'bg-emerald-500/15 text-emerald-400',
    pending: 'bg-amber-500/15 text-amber-400',
    failed: 'bg-red-500/15 text-red-400',
  };
  return (
    <span className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider ${cls[status] ?? 'bg-muted/20 text-muted-foreground'}`}>
      {status}
    </span>
  );
}

function AccountStatusBadge({ status }: { status: AccountStatus }) {
  const styles: Record<AccountStatus, string> = {
    active: 'border-emerald-500/25 bg-emerald-500/12 text-emerald-400',
    suspended: 'border-amber-500/25 bg-amber-500/12 text-amber-400',
    banned: 'border-red-500/25 bg-red-500/12 text-red-400',
  };
  return (
    <span className={`inline-flex rounded-md border px-2 py-1 text-[10px] font-mono font-bold uppercase tracking-wider ${styles[status]}`}>
      {status}
    </span>
  );
}

type ActionUser = Pick<AdminUser, 'clerkUserId' | 'displayName' | 'email' | 'accountStatus'>;
type PendingAccountAction =
  | { kind: 'status'; user: ActionUser; status: AccountStatus }
  | { kind: 'delete'; user: ActionUser };

function UserActionButtons({
  user,
  disabled,
  onAction,
}: {
  user: ActionUser;
  disabled: boolean;
  onAction: (action: PendingAccountAction) => void;
}) {
  const buttonClass = 'inline-flex h-8 items-center gap-1.5 rounded-md border px-2.5 text-[11px] font-bold transition disabled:cursor-not-allowed disabled:opacity-40';
  return (
    <div className="flex flex-wrap items-center gap-1.5" onClick={(event) => event.stopPropagation()}>
      {user.accountStatus !== 'suspended' && (
        <button
          type="button"
          disabled={disabled}
          onClick={() => onAction({ kind: 'status', user, status: 'suspended' })}
          className={`${buttonClass} border-amber-500/25 bg-amber-500/8 text-amber-400 hover:bg-amber-500/15`}
          data-testid={`button-suspend-user-${user.clerkUserId}`}
        >
          <PauseCircle className="h-3.5 w-3.5" /> Suspend
        </button>
      )}
      {user.accountStatus !== 'banned' && (
        <button
          type="button"
          disabled={disabled}
          onClick={() => onAction({ kind: 'status', user, status: 'banned' })}
          className={`${buttonClass} border-red-500/25 bg-red-500/8 text-red-400 hover:bg-red-500/15`}
          data-testid={`button-ban-user-${user.clerkUserId}`}
        >
          <Ban className="h-3.5 w-3.5" /> Ban
        </button>
      )}
      {user.accountStatus !== 'active' && (
        <button
          type="button"
          disabled={disabled}
          onClick={() => onAction({ kind: 'status', user, status: 'active' })}
          className={`${buttonClass} border-emerald-500/25 bg-emerald-500/8 text-emerald-400 hover:bg-emerald-500/15`}
          data-testid={`button-restore-user-${user.clerkUserId}`}
        >
          <RotateCcw className="h-3.5 w-3.5" /> Restore
        </button>
      )}
      <button
        type="button"
        disabled={disabled || user.clerkUserId === 'demo_user'}
        onClick={() => onAction({ kind: 'delete', user })}
        className={`${buttonClass} border-destructive/30 bg-destructive/8 text-destructive hover:bg-destructive/15`}
        title={user.clerkUserId === 'demo_user' ? 'The demo account cannot be deleted' : 'Delete user account'}
        data-testid={`button-delete-user-${user.clerkUserId}`}
      >
        <Trash2 className="h-3.5 w-3.5" /> Delete
      </button>
    </div>
  );
}

function UserDetailDrawer({
  userId,
  onClose,
  onAction,
  actionPending,
}: {
  userId: string;
  onClose: () => void;
  onAction: (action: PendingAccountAction) => void;
  actionPending: boolean;
}) {
  const { data, isLoading, isError } = useAdminUserDetail(userId);
  const [detailTab, setDetailTab] = useState<'holdings' | 'transactions' | 'kyc'>('holdings');

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90dvh] overflow-y-auto bg-card border-border text-foreground p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b border-border">
          {isLoading ? (
            <DialogTitle className="text-muted-foreground font-mono">Loading…</DialogTitle>
          ) : isError || !data ? (
            <DialogTitle className="text-destructive">Failed to load user</DialogTitle>
          ) : (
            <div className="flex items-center gap-4">
              <div className="w-11 h-11 rounded-xl bg-primary/15 grid place-items-center text-primary font-bold text-lg">
                {data.displayName.charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <DialogTitle className="text-lg font-bold">{data.displayName}</DialogTitle>
                <p className="text-xs font-mono text-muted-foreground truncate">{data.email}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <AccountStatusBadge status={data.accountStatus} />
                {data.verificationStatus === 'verified' ? (
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                ) : data.verificationStatus === 'pending' ? (
                  <ShieldAlert className="w-4 h-4 text-amber-500" />
                ) : (
                  <Shield className="w-4 h-4 text-muted-foreground" />
                )}
                <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  {data.verificationStatus}
                </span>
              </div>
            </div>
          )}
        </DialogHeader>

        {!isLoading && !isError && data && (
          <>
            {/* Summary cards */}
            <div className="grid grid-cols-2 gap-3 px-6 py-4 border-b border-border">
              <div className="rounded-xl bg-primary/8 border border-primary/15 p-3">
                <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Portfolio Value</p>
                <p className="mt-1 font-mono text-lg font-medium text-primary">{money(data.totalHoldings)}</p>
              </div>
              <div className="rounded-xl bg-muted/20 border border-border p-3">
                <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Member Since</p>
                <p className="mt-1 font-mono text-sm font-medium">{new Date(data.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
              </div>
            </div>

            <div className="flex flex-col gap-3 border-b border-border px-6 py-4">
              <div>
                <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Account controls</p>
                <p className="mt-1 text-xs text-muted-foreground">Access changes take effect immediately.</p>
              </div>
              <UserActionButtons user={data} disabled={actionPending} onAction={onAction} />
            </div>

            {/* Tabs */}
            <div className="flex gap-0 border-b border-border">
              {(['holdings', 'transactions', 'kyc'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setDetailTab(tab)}
                  className={`flex-1 px-4 py-3 text-xs font-mono font-bold uppercase tracking-wider transition-colors ${
                    detailTab === tab
                      ? 'text-primary border-b-2 border-primary'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="p-6">
              {/* Holdings tab */}
              {detailTab === 'holdings' && (
                <div className="space-y-2">
                  {data.holdings.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-6">No holdings yet.</p>
                  ) : (
                    data.holdings.map((h) => (
                      <div key={h.symbol} className="flex items-center gap-3 rounded-xl bg-muted/10 border border-border px-4 py-3">
                        <span
                          className="w-9 h-9 shrink-0 grid place-items-center rounded-full text-xs font-extrabold text-[#071326]"
                          style={{ backgroundColor: h.color }}
                        >
                          {h.symbol.slice(0, 1)}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-sm">{h.symbol}</p>
                          <p className="text-xs text-muted-foreground">{h.name}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-mono text-sm font-medium">{money(h.value)}</p>
                          <p className={`text-[10px] font-bold ${h.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {h.change24h >= 0 ? '+' : ''}{h.change24h.toFixed(2)}%
                          </p>
                        </div>
                        <div className="hidden sm:block text-right text-xs text-muted-foreground font-mono w-16">
                          {h.allocation.toFixed(1)}%
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Transactions tab */}
              {detailTab === 'transactions' && (
                <div className="space-y-2">
                  {data.transactions.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-6">No transactions yet.</p>
                  ) : (
                    data.transactions.map((tx) => (
                      <div key={tx.id} className="flex items-center gap-3 rounded-xl bg-muted/10 border border-border px-4 py-3">
                        <div className="w-8 h-8 shrink-0 grid place-items-center rounded-xl bg-muted/20">
                          {typeIcon(tx.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm capitalize">{tx.type} · {tx.asset}</p>
                          <p className="text-xs text-muted-foreground font-mono">
                            {new Date(tx.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-mono text-sm">{tx.amount} {tx.asset}</p>
                          <StatusBadge status={tx.status} />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* KYC tab */}
              {detailTab === 'kyc' && (
                <div>
                  {!data.kyc ? (
                    <div className="text-center py-6">
                      <FileCheck className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-40" />
                      <p className="text-sm text-muted-foreground">No KYC submission found.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground">KYC Status</p>
                        <StatusBadge status={data.kyc.status} />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          ['Full Name', data.kyc.fullName],
                          ['Email', data.kyc.email],
                          ['Country', data.kyc.country],
                          ['City / State', data.kyc.city],
                          ['Occupation', data.kyc.occupation],
                          ['Document Type', data.kyc.documentType?.replace(/_/g, ' ')],
                          ['Submitted', new Date(data.kyc.submittedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })],
                        ].map(([label, value]) => (
                          <div key={label} className="rounded-xl bg-muted/10 border border-border p-3">
                            <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">{label}</p>
                            <p className="mt-1 text-sm font-medium truncate">{value || '—'}</p>
                          </div>
                        ))}
                      </div>
                      {/* SSN (sensitive) */}
                      <div className="rounded-xl bg-amber-500/8 border border-amber-500/20 p-3">
                        <p className="text-[10px] font-mono uppercase tracking-wider text-amber-400">SSN (Sensitive)</p>
                        <p className="mt-1 text-sm font-mono font-medium blur-sm select-none hover:blur-none transition-all cursor-pointer" title="Click to reveal">
                          {data.kyc.ssn || '—'}
                        </p>
                      </div>
                      {/* Document image */}
                      {data.kyc.documentImageBase64 && data.kyc.documentImageBase64.startsWith('data:image') && (
                        <div>
                          <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-2">ID Document</p>
                          <a href={data.kyc.documentImageBase64} target="_blank" rel="noopener noreferrer">
                            <img
                              src={data.kyc.documentImageBase64}
                              alt="KYC document"
                              className="max-h-56 w-full object-contain rounded-xl border border-border bg-muted/20 cursor-zoom-in"
                            />
                            <p className="mt-1 text-xs text-muted-foreground">Click to open full size ↗</p>
                          </a>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        )}

        {isLoading && (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function Users() {
  const { data: users, isLoading } = useAdminUsers();
  const [search, setSearch] = useState('');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [pendingAction, setPendingAction] = useState<PendingAccountAction | null>(null);
  const updateStatus = useUpdateAdminUserStatus();
  const deleteUser = useDeleteAdminUser();
  const { toast } = useToast();
  const actionPending = updateStatus.isPending || deleteUser.isPending;

  const filtered = users?.filter(u =>
    u.displayName.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const confirmAction = async () => {
    if (!pendingAction) return;
    try {
      if (pendingAction.kind === 'delete') {
        await deleteUser.mutateAsync(pendingAction.user.clerkUserId);
        if (selectedUserId === pendingAction.user.clerkUserId) setSelectedUserId(null);
        toast({
          title: 'User deleted',
          description: `${pendingAction.user.displayName} and their application data were removed.`,
        });
      } else {
        await updateStatus.mutateAsync({
          userId: pendingAction.user.clerkUserId,
          status: pendingAction.status,
        });
        const label = pendingAction.status === 'active' ? 'restored' : pendingAction.status;
        toast({
          title: `Account ${label}`,
          description: `${pendingAction.user.displayName}'s account is now ${pendingAction.status}.`,
        });
      }
      setPendingAction(null);
    } catch (error) {
      toast({
        title: 'Account action failed',
        description: error instanceof Error ? error.message : 'Please try again.',
        variant: 'destructive',
      });
    }
  };

  const actionDescription = pendingAction?.kind === 'delete'
    ? `Permanently delete ${pendingAction.user.displayName} and all of their wallet, transaction, KYC, trading, security, activity, and support records. This cannot be undone.`
    : pendingAction?.status === 'active'
      ? `Restore ${pendingAction?.user.displayName}'s access to the platform.`
      : `${pendingAction?.status === 'banned' ? 'Ban' : 'Suspend'} ${pendingAction?.user.displayName}'s account and immediately block access to protected features.`;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-mono tracking-tight">User Directory</h1>
          <p className="text-muted-foreground text-sm mt-1">Click any user to inspect their account.</p>
        </div>
        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search users..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-card border border-border rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary font-sans"
          />
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground bg-muted/20 uppercase font-mono">
              <tr>
                <th className="px-5 py-4 font-medium">User</th>
                <th className="px-5 py-4 font-medium">Account status</th>
                <th className="px-5 py-4 font-medium">Verification</th>
                <th className="px-5 py-4 font-medium">Portfolio</th>
                <th className="px-5 py-4 font-medium">Joined</th>
                <th className="px-5 py-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-muted-foreground">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-primary" />
                    Loading directory...
                  </td>
                </tr>
              ) : !filtered || filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-muted-foreground">
                    No users found.
                  </td>
                </tr>
              ) : (
                filtered.map(user => (
                  <tr
                    key={user.id}
                    className="hover:bg-muted/8 transition-colors cursor-pointer group"
                    onClick={() => setSelectedUserId(user.clerkUserId)}
                  >
                    <td className="px-5 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold text-xs">
                          {user.displayName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-medium text-foreground">{user.displayName}</div>
                          <div className="text-xs text-muted-foreground font-mono">{user.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <AccountStatusBadge status={user.accountStatus} />
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center space-x-2">
                        {user.verificationStatus === 'verified' ? (
                          <ShieldCheck className="w-4 h-4 text-emerald-500" />
                        ) : user.verificationStatus === 'pending' ? (
                          <ShieldAlert className="w-4 h-4 text-amber-500" />
                        ) : (
                          <Shield className="w-4 h-4 text-muted-foreground" />
                        )}
                        <span className="text-xs font-mono uppercase tracking-wider">
                          {user.verificationStatus}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="font-mono text-foreground">
                        ${user.totalHoldings.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                    </td>
                    <td className="px-5 py-4 text-xs font-mono text-muted-foreground">
                      {new Date(user.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-5 py-4">
                      <UserActionButtons user={user} disabled={actionPending} onAction={setPendingAction} />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {selectedUserId && (
        <UserDetailDrawer
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
          onAction={setPendingAction}
          actionPending={actionPending}
        />
      )}

      <AlertDialog
        open={pendingAction !== null}
        onOpenChange={(open) => {
          if (!open && !actionPending) setPendingAction(null);
        }}
      >
        <AlertDialogContent className="border-border bg-card">
          <AlertDialogHeader>
            <div className="mb-2 grid h-11 w-11 place-items-center rounded-xl bg-destructive/12 text-destructive">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <AlertDialogTitle>
              {pendingAction?.kind === 'delete'
                ? 'Delete user account?'
                : pendingAction?.status === 'active'
                  ? 'Restore user access?'
                  : `${pendingAction?.status === 'banned' ? 'Ban' : 'Suspend'} user account?`}
            </AlertDialogTitle>
            <AlertDialogDescription>{actionDescription}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={actionPending}
              onClick={(event) => {
                event.preventDefault();
                void confirmAction();
              }}
              className={pendingAction?.kind === 'delete' || pendingAction?.status === 'banned'
                ? 'border-destructive bg-destructive text-destructive-foreground'
                : ''}
              data-testid="button-confirm-account-action"
            >
              {actionPending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {pendingAction?.kind === 'delete'
                ? 'Delete permanently'
                : pendingAction?.status === 'active'
                  ? 'Restore access'
                  : pendingAction?.status === 'banned'
                    ? 'Ban account'
                    : 'Suspend account'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
